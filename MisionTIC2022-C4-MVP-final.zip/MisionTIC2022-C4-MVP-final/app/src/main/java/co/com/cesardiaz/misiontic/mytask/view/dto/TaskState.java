package co.com.cesardiaz.misiontic.mytask.view.dto;

public enum TaskState {
    PENDING,
    DONE
}
